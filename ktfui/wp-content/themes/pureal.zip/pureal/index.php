<?php get_header(); ?>
	<div id="landing-home" class="row-fullwidth">
		<div class="row-fullwidth-container">
			
		</div>
	</div>
	<div class="row-fullwidth">
		<div class="row-fullwidth-container">
			<h1>OUR SPECIALITY</h1>
			<a class="rounded" href="#"><img src="#"/></a>
			<a class="rounded" href="#"><img src="#"/></a>
			<a class="rounded" href="#"><img src="#"/></a>
		</div>
	</div>
<?php get_footer(); ?>